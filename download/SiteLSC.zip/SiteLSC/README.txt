﻿Olá! Este Website foi implementado para divulgar os trabalhos desenvolvidos na grade curricular da Faculdade de Tecnologia de Carapicuiba utilizando HTML 5, CSS, Javascript, Bootstrap e PHP. Para avaliação do desenvolvimento efetue o download código fonte do site no botão abaixo.

A página SiteLSC esta organizada na seguinte estrutura na raiz:

-index.html
---contato.html
---curriculo.html
---jogosdigitais.html
---viagens.html
---pesquisa.php (apenas quando logado)

Para se logar no site, acessar com usuário: admin  e senha: 123


Descrição dos Diretórios:
raiz: encontram-se os arquivos .php, páginas html e o script de banco de dados (.sql) utilizado no projeto
css: arquivos do bootstrap e template do site (morden-bussiness.css)
download: pasta com os arquivos de projetos compactados. Incluindo o código fonte do projeto do Site
font-awsome: neste diretório encontram fontes, arquivos .less e .scss (aceleradores de desenvolvimento CSS)
fonts: demais fontes utilizadas no projeto
images: diretório de imagens do site
js: arquivos javascript do projeto, arquivo padrões de configuração do jquery e bootstrap 

Copyright © LSC Site 2018 - Portfolio WEB/Fatec Carapicuiba